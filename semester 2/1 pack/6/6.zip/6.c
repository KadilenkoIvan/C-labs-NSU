﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <time.h>

#define m 1000000007

typedef struct evclid_s
{
	int ans;
	int x;
	int y;
}evclid;

evclid gcd(int a, int b, evclid num)
{
	if (b == 0)
	{
		num.ans = a;
		num.x = 1;
		num.y = 0;
		return num;
	}

	num = gcd(b, a % b, num);

	int buf = num.x;
	num.x = num.y;
	num.y = buf - num.y * (a / b);
	return num;
}

unsigned long long fact(int n)
{
	unsigned long long ans = 1, new_n = (unsigned long long)n;
	for (unsigned long long i = new_n; i > 1; --i)
	{
		ans = ((ans % m) * (i % m)) % m;
	}
	return ans;
}

int main()
{
	int t = 0;
	scanf("%d", &t);

	evclid num;
	
	unsigned long long ans = 0, f = 0, s = 0, th = 0;
	int n = 0, k = 0;
	for (int i = 0; i < t; ++i)
	{
		scanf("%d%d", &n, &k);

		f = fact(n);
		s = fact(k);
		th = fact(n - k);

		num.ans = 0;
		num.x = 0;
		num.y = 0;

		s = (gcd(m, s, num).y + m) % m;
		ans = (f * s) % m;

		num.ans = 0;
		num.x = 0;
		num.y = 0;

		th = (gcd(m, th, num).y + m) % m;
		ans = (ans * th) % m;

		//ans = (fact(n) / fact(k) / fact(n - k)) % m;
		printf("%llu\n", ans);
	}
	return 0;
}